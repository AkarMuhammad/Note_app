package com.example.myapplication;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "todo_notes_db";

    // Table Names
    private static final String TABLE_TASKS = "tasks";
    private static final String TABLE_NOTES = "notes";

    // Common Column Names
    private static final String KEY_ID = "id";
    private static final String KEY_CREATED_AT = "created_at";

    // TASKS Table - Column Names
    private static final String KEY_TASK = "task";
    private static final String KEY_STATUS = "status";
    private static final String KEY_DUE_DATE = "due_date";
    private static final String KEY_PRIORITY = "priority";

    // NOTES Table - Column Names
    private static final String KEY_TITLE = "title";
    private static final String KEY_CONTENT = "content";
    private static final String KEY_COLOR = "color";

    // Table Create Statements
    // Tasks table create statement
    private static final String CREATE_TABLE_TASKS = "CREATE TABLE " + TABLE_TASKS + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_TASK + " TEXT,"
            + KEY_STATUS + " INTEGER DEFAULT 0,"
            + KEY_DUE_DATE + " DATETIME,"
            + KEY_PRIORITY + " INTEGER DEFAULT 0,"
            + KEY_CREATED_AT + " DATETIME" + ")";

    // Notes table create statement
    private static final String CREATE_TABLE_NOTES = "CREATE TABLE " + TABLE_NOTES + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_TITLE + " TEXT,"
            + KEY_CONTENT + " TEXT,"
            + KEY_COLOR + " TEXT,"
            + KEY_CREATED_AT + " DATETIME" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creating required tables
        db.execSQL(CREATE_TABLE_TASKS);
        db.execSQL(CREATE_TABLE_NOTES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // On upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);

        // Create new tables
        onCreate(db);
    }

    // ===== TASK METHODS =====

    /**
     * Add a new task
     */
    public long createTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TASK, task.getTask());
        values.put(KEY_STATUS, task.getStatus());
        values.put(KEY_DUE_DATE, task.getDueDate());
        values.put(KEY_PRIORITY, task.getPriority());
        values.put(KEY_CREATED_AT, System.currentTimeMillis());

        // Insert row
        long id = db.insert(TABLE_TASKS, null, values);
        db.close();
        return id;
    }

    /**
     * Get single task
     */
    public Task getTask(long task_id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + TABLE_TASKS + " WHERE "
                + KEY_ID + " = " + task_id;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null && c.moveToFirst()) {
            Task task = new Task();
            task.setId(c.getInt(c.getColumnIndex(KEY_ID)));
            task.setTask(c.getString(c.getColumnIndex(KEY_TASK)));
            task.setStatus(c.getInt(c.getColumnIndex(KEY_STATUS)));
            task.setDueDate(c.getString(c.getColumnIndex(KEY_DUE_DATE)));
            task.setPriority(c.getInt(c.getColumnIndex(KEY_PRIORITY)));
            task.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
            c.close();
            return task;
        }
        if (c != null) {
            c.close();
        }
        return null;
    }

    /**
     * Get all tasks
     */
    public List<Task> getAllTasks() {
        List<Task> tasks = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_TASKS + " ORDER BY " + KEY_PRIORITY + " DESC, " + KEY_CREATED_AT + " DESC";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // Looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                Task task = new Task();
                task.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                task.setTask(c.getString(c.getColumnIndex(KEY_TASK)));
                task.setStatus(c.getInt(c.getColumnIndex(KEY_STATUS)));
                task.setDueDate(c.getString(c.getColumnIndex(KEY_DUE_DATE)));
                task.setPriority(c.getInt(c.getColumnIndex(KEY_PRIORITY)));
                task.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));

                // Adding to tasks list
                tasks.add(task);
            } while (c.moveToNext());
        }
        c.close();
        return tasks;
    }

    /**
     * Update a task
     */
    public int updateTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TASK, task.getTask());
        values.put(KEY_STATUS, task.getStatus());
        values.put(KEY_DUE_DATE, task.getDueDate());
        values.put(KEY_PRIORITY, task.getPriority());

        // Updating row
        return db.update(TABLE_TASKS, values, KEY_ID + " = ?",
                new String[]{String.valueOf(task.getId())});
    }

    /**
     * Delete a task
     */
    public void deleteTask(long task_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_TASKS, KEY_ID + " = ?",
                new String[]{String.valueOf(task_id)});
    }

    // ===== NOTE METHODS =====

    /**
     * Add a new note
     */
    public long createNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, note.getTitle());
        values.put(KEY_CONTENT, note.getContent());
        values.put(KEY_COLOR, note.getColor());
        values.put(KEY_CREATED_AT, System.currentTimeMillis());

        // Insert row
        long id = db.insert(TABLE_NOTES, null, values);
        db.close();
        return id;
    }

    /**
     * Get single note
     */
    public Note getNote(long note_id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + TABLE_NOTES + " WHERE "
                + KEY_ID + " = " + note_id;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null && c.moveToFirst()) {
            Note note = new Note();
            note.setId(c.getInt(c.getColumnIndex(KEY_ID)));
            note.setTitle(c.getString(c.getColumnIndex(KEY_TITLE)));
            note.setContent(c.getString(c.getColumnIndex(KEY_CONTENT)));
            note.setColor(c.getString(c.getColumnIndex(KEY_COLOR)));
            note.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));
            c.close();
            return note;
        }
        if (c != null) {
            c.close();
        }
        return null;
    }

    /**
     * Get all notes
     */
    public List<Note> getAllNotes() {
        List<Note> notes = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_NOTES + " ORDER BY " + KEY_CREATED_AT + " DESC";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // Looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                Note note = new Note();
                note.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                note.setTitle(c.getString(c.getColumnIndex(KEY_TITLE)));
                note.setContent(c.getString(c.getColumnIndex(KEY_CONTENT)));
                note.setColor(c.getString(c.getColumnIndex(KEY_COLOR)));
                note.setCreatedAt(c.getString(c.getColumnIndex(KEY_CREATED_AT)));

                // Adding to notes list
                notes.add(note);
            } while (c.moveToNext());
        }
        c.close();
        return notes;
    }

    /**
     * Update a note
     */
    public int updateNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, note.getTitle());
        values.put(KEY_CONTENT, note.getContent());
        values.put(KEY_COLOR, note.getColor());

        // Updating row
        return db.update(TABLE_NOTES, values, KEY_ID + " = ?",
                new String[]{String.valueOf(note.getId())});
    }

    /**
     * Delete a note
     */
    public void deleteNote(long note_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NOTES, KEY_ID + " = ?",
                new String[]{String.valueOf(note_id)});
    }
}