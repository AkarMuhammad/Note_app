package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class NoteListActivity extends AppCompatActivity {

    private GridView gridViewNotes;
    private FloatingActionButton fabAddNote;
    private DatabaseHelper db;
    private List<Note> noteList;
    private NoteAdapter noteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);

        // Initialize toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Notes");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize views
        gridViewNotes = findViewById(R.id.gridViewNotes);
        fabAddNote = findViewById(R.id.fabAddNote);

        // Initialize database
        db = new DatabaseHelper(this);

        // Set click listener for floating action button
        fabAddNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NoteListActivity.this, NoteDetailActivity.class);
                startActivity(intent);
            }
        });

        // Load notes
        loadNoteList();

        // Set click listener for grid items
        gridViewNotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Note note = noteList.get(position);
                Intent intent = new Intent(NoteListActivity.this, NoteDetailActivity.class);
                intent.putExtra("note_id", note.getId());
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNoteList();
    }

    private void loadNoteList() {
        noteList = db.getAllNotes();
        noteAdapter = new NoteAdapter(this, noteList);
        gridViewNotes.setAdapter(noteAdapter);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}