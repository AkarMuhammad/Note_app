package com.example.myapplication;



import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

public class NoteDetailActivity extends AppCompatActivity {

    private EditText editTitle, editContent;
    private LinearLayout colorPalette;
    private CardView cardPreview;
    private DatabaseHelper db;
    private Note currentNote;
    private String selectedColor = "#FFFFFF"; // Default color: white

    private static final String[] NOTE_COLORS = {
            "#FFFFFF", // White
            "#FFCDD2", // Light Red
            "#F8BBD0", // Light Pink
            "#E1BEE7", // Light Purple
            "#D1C4E9", // Light Deep Purple
            "#C5CAE9", // Light Indigo
            "#BBDEFB", // Light Blue
            "#B3E5FC", // Light Light Blue
            "#B2EBF2", // Light Cyan
            "#B2DFDB", // Light Teal
            "#C8E6C9", // Light Green
            "#DCEDC8", // Light Light Green
            "#F0F4C3", // Light Lime
            "#FFF9C4", // Light Yellow
            "#FFECB3", // Light Amber
            "#FFE0B2"  // Light Orange
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_detail);

        // Initialize toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize views
        editTitle = findViewById(R.id.editTitle);
        editContent = findViewById(R.id.editContent);
        colorPalette = findViewById(R.id.colorPalette);
        cardPreview = findViewById(R.id.cardPreview);

        // Initialize database
        db = new DatabaseHelper(this);

        // Check if editing existing note
        int noteId = getIntent().getIntExtra("note_id", -1);
        if (noteId != -1) {
            // Editing existing note
            currentNote = db.getNote(noteId);
            if (currentNote != null) {
                editTitle.setText(currentNote.getTitle());
                editContent.setText(currentNote.getContent());
                selectedColor = currentNote.getColor() != null ? currentNote.getColor() : "#FFFFFF";
                cardPreview.setCardBackgroundColor(android.graphics.Color.parseColor(selectedColor));
                getSupportActionBar().setTitle("Edit Note");
            }
        } else {
            // Creating new note
            getSupportActionBar().setTitle("New Note");
            currentNote = new Note();
        }

        // Setup color palette
        setupColorPalette();
    }

    private void setupColorPalette() {
        colorPalette.removeAllViews();

        for (final String color : NOTE_COLORS) {
            View colorView = new View(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    (int) getResources().getDimension(R.dimen.color_swatch_size),
                    (int) getResources().getDimension(R.dimen.color_swatch_size)
            );
            params.setMargins(8, 0, 8, 0);
            colorView.setLayoutParams(params);
            colorView.setBackgroundColor(android.graphics.Color.parseColor(color));

            // Add border if this is the selected color
            if (color.equals(selectedColor)) {
                colorView.setBackground(ContextCompat.getDrawable(this, R.drawable.color_swatch_selected));
                colorView.setBackgroundColor(android.graphics.Color.parseColor(color));

            }

            colorView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedColor = color;
                    cardPreview.setCardBackgroundColor(android.graphics.Color.parseColor(selectedColor));
                    setupColorPalette(); // Refresh to show selection
                }
            });

            colorPalette.addView(colorView);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_note_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_save) {
            saveNote();
            return true;
        } else if (id == R.id.action_delete) {
            if (currentNote.getId() > 0) {
                showDeleteConfirmationDialog();
            } else {
                Toast.makeText(this, "Note not saved yet", Toast.LENGTH_SHORT).show();
            }
            return true;
        } else if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void saveNote() {
        String title = editTitle.getText().toString().trim();
        String content = editContent.getText().toString().trim();

        if (title.isEmpty() && content.isEmpty()) {
            Toast.makeText(this, "Cannot save empty note", Toast.LENGTH_SHORT).show();
            return;
        }

        // If title is empty, use first line of content as title
        if (title.isEmpty()) {
            String[] lines = content.split("\n", 2);
            title = lines[0];
            if (title.length() > 30) {
                title = title.substring(0, 30) + "...";
            }
        }

        currentNote.setTitle(title);
        currentNote.setContent(content);
        currentNote.setColor(selectedColor);

        if (currentNote.getId() > 0) {
            // Update existing note
            db.updateNote(currentNote);
            Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
        } else {
            // Create new note
            long id = db.createNote(currentNote);
            currentNote.setId((int) id);
            Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Note");
        builder.setMessage("Are you sure you want to delete this note?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                db.deleteNote(currentNote.getId());
                Toast.makeText(NoteDetailActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public void onBackPressed() {
        String title = editTitle.getText().toString().trim();
        String content = editContent.getText().toString().trim();

        if (!title.isEmpty() || !content.isEmpty()) {
            if (currentNote.getId() > 0) {
                if (!title.equals(currentNote.getTitle()) || !content.equals(currentNote.getContent()) || !selectedColor.equals(currentNote.getColor())) {
                    showSaveConfirmationDialog();
                    return;
                }
            } else {
                showSaveConfirmationDialog();
                return;
            }
        }
        super.onBackPressed();
    }

    private void showSaveConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Save Note");
        builder.setMessage("Do you want to save changes to this note?");
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveNote();
            }
        });
        builder.setNegativeButton("Discard", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNeutralButton("Cancel", null);
        builder.show();
    }
}