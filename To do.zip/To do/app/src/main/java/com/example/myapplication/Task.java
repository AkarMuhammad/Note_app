package com.example.myapplication;
public class Task {
    private int id;
    private String task;
    private int status; // 0 = pending, 1 = completed
    private String dueDate;
    private int priority; // 0 = low, 1 = medium, 2 = high
    private String createdAt;

    public Task() {
    }

    public Task(String task, int status, String dueDate, int priority) {
        this.task = task;
        this.status = status;
        this.dueDate = dueDate;
        this.priority = priority;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}