package com.example.myapplication;


import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class TaskListActivity extends AppCompatActivity {

    private ListView listViewTasks;
    private FloatingActionButton fabAddTask;
    private DatabaseHelper db;
    private List<Task> taskList;
    private TaskAdapter taskAdapter;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);

        // Initialize toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Tasks");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize views
        listViewTasks = findViewById(R.id.listViewTasks);
        fabAddTask = findViewById(R.id.fabAddTask);

        // Initialize database
        db = new DatabaseHelper(this);

        // Initialize calendar and date format
        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

        // Set click listener for floating action button
        fabAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddTaskDialog();
            }
        });

        // Load tasks
        loadTaskList();

        // Set click listener for list items
        listViewTasks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Task task = taskList.get(position);
                showTaskOptionsDialog(task);
            }
        });
    }

    private void loadTaskList() {
        taskList = db.getAllTasks();
        taskAdapter = new TaskAdapter(this, taskList);
        listViewTasks.setAdapter(taskAdapter);
    }

    private void showAddTaskDialog() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.dialog_add_task, null);
        dialogBuilder.setView(dialogView);

        final EditText editTaskName = dialogView.findViewById(R.id.editTaskName);
        final Button btnSelectDate = dialogView.findViewById(R.id.btnSelectDate);
        final RadioGroup radioGroupPriority = dialogView.findViewById(R.id.radioGroupPriority);

        btnSelectDate.setText(dateFormat.format(calendar.getTime()));

        btnSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(btnSelectDate);
            }
        });

        dialogBuilder.setTitle("Add New Task");
        dialogBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                String taskName = editTaskName.getText().toString().trim();
                String dueDate = btnSelectDate.getText().toString();

                int priorityId = radioGroupPriority.getCheckedRadioButtonId();
                int priority = 0; // Default: Low

                if (priorityId == R.id.radioPriorityMedium) {
                    priority = 1;
                } else if (priorityId == R.id.radioPriorityHigh) {
                    priority = 2;
                }

                if (taskName.isEmpty()) {
                    Toast.makeText(TaskListActivity.this, "Task name cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Create new task
                Task task = new Task(taskName, 0, dueDate, priority);
                db.createTask(task);

                // Refresh the list
                loadTaskList();

                Toast.makeText(TaskListActivity.this, "Task added successfully", Toast.LENGTH_SHORT).show();
            }
        });

        dialogBuilder.setNegativeButton("Cancel", null);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    private void showTaskOptionsDialog(final Task task) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Task Options");

        final CharSequence[] options = {"Mark as " + (task.getStatus() == 0 ? "Completed" : "Incomplete"), "Edit", "Delete"};

        dialogBuilder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Toggle status
                        task.setStatus(task.getStatus() == 0 ? 1 : 0);
                        db.updateTask(task);
                        loadTaskList();
                        break;
                    case 1: // Edit
                        showEditTaskDialog(task);
                        break;
                    case 2: // Delete
                        showDeleteConfirmationDialog(task);
                        break;
                }
            }
        });

        dialogBuilder.setNegativeButton("Cancel", null);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    private void showEditTaskDialog(final Task task) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.dialog_add_task, null);
        dialogBuilder.setView(dialogView);

        final EditText editTaskName = dialogView.findViewById(R.id.editTaskName);
        final Button btnSelectDate = dialogView.findViewById(R.id.btnSelectDate);
        final RadioGroup radioGroupPriority = dialogView.findViewById(R.id.radioGroupPriority);

        editTaskName.setText(task.getTask());
        btnSelectDate.setText(task.getDueDate());

        switch (task.getPriority()) {
            case 0:
                radioGroupPriority.check(R.id.radioPriorityLow);
                break;
            case 1:
                radioGroupPriority.check(R.id.radioPriorityMedium);
                break;
            case 2:
                radioGroupPriority.check(R.id.radioPriorityHigh);
                break;
        }

        btnSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(btnSelectDate);
            }
        });

        dialogBuilder.setTitle("Edit Task");
        dialogBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                String taskName = editTaskName.getText().toString().trim();
                String dueDate = btnSelectDate.getText().toString();

                int priorityId = radioGroupPriority.getCheckedRadioButtonId();
                int priority = 0; // Default: Low

                if (priorityId == R.id.radioPriorityMedium) {
                    priority = 1;
                } else if (priorityId == R.id.radioPriorityHigh) {
                    priority = 2;
                }

                if (taskName.isEmpty()) {
                    Toast.makeText(TaskListActivity.this, "Task name cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Update task
                task.setTask(taskName);
                task.setDueDate(dueDate);
                task.setPriority(priority);
                db.updateTask(task);

                // Refresh the list
                loadTaskList();

                Toast.makeText(TaskListActivity.this, "Task updated successfully", Toast.LENGTH_SHORT).show();
            }
        });

        dialogBuilder.setNegativeButton("Cancel", null);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    private void showDeleteConfirmationDialog(final Task task) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Delete Task");
        dialogBuilder.setMessage("Are you sure you want to delete this task?");

        dialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                db.deleteTask(task.getId());
                loadTaskList();
                Toast.makeText(TaskListActivity.this, "Task deleted successfully", Toast.LENGTH_SHORT).show();
            }
        });

        dialogBuilder.setNegativeButton("No", null);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    private void showDatePickerDialog(final Button dateButton) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        dateButton.setText(dateFormat.format(calendar.getTime()));
                    }
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}