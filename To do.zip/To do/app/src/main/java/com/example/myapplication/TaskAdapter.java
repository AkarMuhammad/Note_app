package com.example.myapplication;



import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.util.List;

public class TaskAdapter extends ArrayAdapter<Task> {

    private Context context;
    private List<Task> taskList;
    private DatabaseHelper db;

    public TaskAdapter(Context context, List<Task> taskList) {
        super(context, R.layout.task_list_item, taskList);
        this.context = context;
        this.taskList = taskList;
        this.db = new DatabaseHelper(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.task_list_item, parent, false);

            holder = new ViewHolder();
            holder.checkBoxStatus = convertView.findViewById(R.id.checkBoxStatus);
            holder.tvTaskName = convertView.findViewById(R.id.tvTaskName);
            holder.tvDueDate = convertView.findViewById(R.id.tvDueDate);
            holder.priorityIndicator = convertView.findViewById(R.id.priorityIndicator);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final Task task = taskList.get(position);

        holder.tvTaskName.setText(task.getTask());
        holder.tvDueDate.setText(task.getDueDate());

        // Set checkbox without triggering listener
        holder.checkBoxStatus.setOnCheckedChangeListener(null);
        holder.checkBoxStatus.setChecked(task.getStatus() == 1);

        // Apply strikethrough if task is completed
        if (task.getStatus() == 1) {
            holder.tvTaskName.setPaintFlags(holder.tvTaskName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            holder.tvTaskName.setPaintFlags(holder.tvTaskName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
        }

        // Set priority indicator color
        switch (task.getPriority()) {
            case 0: // Low
                holder.priorityIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPriorityLow));
                break;
            case 1: // Medium
                holder.priorityIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPriorityMedium));
                break;
            case 2: // High
                holder.priorityIndicator.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPriorityHigh));
                break;
        }

        // Set checkbox listener
        holder.checkBoxStatus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                task.setStatus(isChecked ? 1 : 0);
                db.updateTask(task);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }

    static class ViewHolder {
        CheckBox checkBoxStatus;
        TextView tvTaskName;
        TextView tvDueDate;
        View priorityIndicator;
    }
}