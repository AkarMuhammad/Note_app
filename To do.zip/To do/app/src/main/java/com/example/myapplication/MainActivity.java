package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    private CardView cardTasks, cardNotes;
    private TextView tvTaskCount, tvNoteCount;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        cardTasks = findViewById(R.id.cardTasks);
        cardNotes = findViewById(R.id.cardNotes);
        tvTaskCount = findViewById(R.id.tvTaskCount);
        tvNoteCount = findViewById(R.id.tvNoteCount);

        // Initialize database
        db = new DatabaseHelper(this);

        // Set click listeners
        cardTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TaskListActivity.class);
                startActivity(intent);
            }
        });

        cardNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NoteListActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCounters();
    }

    private void updateCounters() {
        // Update task count
        int taskCount = db.getAllTasks().size();
        tvTaskCount.setText(String.valueOf(taskCount));

        // Update note count
        int noteCount = db.getAllNotes().size();
        tvNoteCount.setText(String.valueOf(noteCount));
    }
}