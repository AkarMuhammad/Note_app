package com.example.myapplication;



import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import java.util.List;

public class NoteAdapter extends ArrayAdapter<Note> {

    private Context context;
    private List<Note> noteList;

    public NoteAdapter(Context context, List<Note> noteList) {
        super(context, R.layout.note_grid_item, noteList);
        this.context = context;
        this.noteList = noteList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.note_grid_item, parent, false);

            holder = new ViewHolder();
            holder.cardNote = convertView.findViewById(R.id.cardNote);
            holder.tvNoteTitle = convertView.findViewById(R.id.tvNoteTitle);
            holder.tvNoteContent = convertView.findViewById(R.id.tvNoteContent);
            holder.tvNoteDate = convertView.findViewById(R.id.tvNoteDate);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Note note = noteList.get(position);

        holder.tvNoteTitle.setText(note.getTitle());

        // Display a preview of the content (first 50 characters)
        String contentPreview = note.getContent();
        if (contentPreview.length() > 50) {
            contentPreview = contentPreview.substring(0, 50) + "...";
        }
        holder.tvNoteContent.setText(contentPreview);

        // Display formatted date
        holder.tvNoteDate.setText(note.getCreatedAt());

        // Set card background color based on note color or default to white
        if (note.getColor() != null && !note.getColor().isEmpty()) {
            holder.cardNote.setCardBackgroundColor(Color.parseColor(note.getColor()));

            // Set text color based on background brightness for better readability
            boolean isDarkBackground = isDarkColor(Color.parseColor(note.getColor()));
            int textColor = isDarkBackground ? Color.WHITE : Color.BLACK;
            holder.tvNoteTitle.setTextColor(textColor);
            holder.tvNoteContent.setTextColor(textColor);
            holder.tvNoteDate.setTextColor(textColor);
        } else {
            holder.cardNote.setCardBackgroundColor(Color.WHITE);
            holder.tvNoteTitle.setTextColor(Color.BLACK);
            holder.tvNoteContent.setTextColor(Color.BLACK);
            holder.tvNoteDate.setTextColor(Color.GRAY);
        }

        return convertView;
    }

    // Helper method to determine if a color is dark
    private boolean isDarkColor(int color) {
        double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
        return darkness >= 0.5;
    }

    static class ViewHolder {
        CardView cardNote;
        TextView tvNoteTitle;
        TextView tvNoteContent;
        TextView tvNoteDate;
    }
}